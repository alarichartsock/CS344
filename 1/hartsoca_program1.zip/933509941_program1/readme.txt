How to compile:

$ gcc -o movies movies.c
$ /path/to/executable/movies [sample_input_file]

Example:

$ gcc -o movies movies.c
$ /path/to/executable/movies movies_sample_1.csv

If it doesn't compile or if you have any questions then email me at hartsoca@oregonstate.edu. 
I have successfully compiled and ran on the os1 server and it worked on April 4 4pm. 